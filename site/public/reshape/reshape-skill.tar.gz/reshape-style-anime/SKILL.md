---
name: reshape-style-anime
description: Model or review 3D character forms derived from anime design in Blender. Use when the ReShape brief calls for this visual treatment.
---

# Anime-style modeling

Follow the [required visual reference and review workflow](../reshape/SKILL.md#required-visual-reference). For mixed briefs, see [the styles overview](../reshape-styles/SKILL.md).

## Visual references

- [DillonGoo Studios 3D anime reel](https://www.youtube.com/watch?v=cRzE-0P10_c). Pause on turns and compare hair groups, facial depth, and eye placement across angles.
- [DillonGoo Studios project gallery](https://www.dillongoostudios.com/animations). Use the studio's trailers to compare a character's face and silhouette between compositions.

Use these examples to study visual decisions. Use the user's own target for likeness, dimensions, and design requirements.

## Modeling pass

Set front and profile relationships for the eye socket, cheek, nose, mouth, and jaw. Plan hair as groups with roots, thickness, and a readable outer contour. Document the camera range for any view-dependent facial controls.

## Approval checks

Check the clay model at the key camera and yaw extremes. Test profile, expression, lid contact, and hair overlap. Apply the cel-shading skill when stepped lighting or outlines are part of the brief.

Reject and correct these failures before approval. Eye planes clipping the face, hair strips floating off the scalp, or a broken profile within the intended camera range. Record any remaining issue as partial delivery with a named view and cause.
