---
name: reshape-anatomy-lower-limb
description: >-
  Model or review the pelvis, thigh, knee, lower leg, ankle, and foot as a chain in human anatomy with Blender or ReShape. Use when this region is in scope for 3D modeling or visual review.
---

# Whole lower limb

Follow the subject, pose, and style reference for form, variation, and asymmetry. Record landmarks and views for measurements. Use population averages as context and mark hidden or inferred regions.

## Visual references

- [OpenStax Figures 8.12 and 8.13, pelvis and hip bone](https://openstax.org/books/anatomy-and-physiology-2e/pages/8-3-the-pelvic-girdle-and-pelvis). Locate the acetabulum before aligning the limb.
- [OpenStax Figures 8.16–8.19, lower limb and foot](https://openstax.org/books/anatomy-and-physiology-2e/pages/8-4-bones-of-the-lower-limb). Trace the bony chain and the foot stance landmarks.

Use the figures to locate structures. Compare external forms and pose against the subject reference.

## Modeling

Anchor the thigh at the acetabulum, locate knee and ankle axes, and establish foot contact before refining muscles.

## Evidence to capture

Record a standing sheet with a visible ground line and the joint centers. For a rig, capture a flexed stance and check knee orientation and sole contact.

## Review and rejection

Inspect standing front, rear, and side views. If rigged, test a flexed pose and check ground contact and knee alignment.

Reject these defects when they conflict with the documented target. A foot twisted out of the chain without justification, a reversed knee, or floating support.

Apply the saved-file review in [ReShape](../reshape/SKILL.md). Record the view and discrepancy, correct the cause, and recapture. Missing evidence for a required criterion blocks regional approval.

## Regional skills

Read the relevant regional skills for local criteria.

- [Pelvis and hips](../reshape-anatomy-pelvis/SKILL.md)
- [Thigh](../reshape-anatomy-thigh/SKILL.md)
- [Knee](../reshape-anatomy-knee/SKILL.md)
- [Lower leg and calf](../reshape-anatomy-lower-leg/SKILL.md)
- [Ankle](../reshape-anatomy-ankle/SKILL.md)
- [Whole foot](../reshape-anatomy-foot/SKILL.md)

## Anatomy sources

The sources support the anatomy and anthropometry. The construction and visual review criteria apply that evidence to 3D modeling.

- [OpenStax, Pelvis (8.3)](https://openstax.org/books/anatomy-and-physiology-2e/pages/8-3-the-pelvic-girdle-and-pelvis)
- [OpenStax, Bones of the lower limb (8.4)](https://openstax.org/books/anatomy-and-physiology-2e/pages/8-4-bones-of-the-lower-limb)
- [OpenStax, Pelvic girdle and lower limb muscles (ch. 11)](https://openstax.org/books/anatomy-and-physiology-2e/pages/11-chapter-review)
- [OpenStax, Synovial joints (ch. 9)](https://openstax.org/books/anatomy-and-physiology-2e/pages/9-chapter-review)
